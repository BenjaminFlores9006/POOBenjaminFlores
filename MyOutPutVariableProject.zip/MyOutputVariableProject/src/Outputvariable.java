import java.text.*;
import java.util.locale;
/**
 * 
 */

/**
 * 
 */
public class Outputvariable {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		long numero = 123098
		double pi = MATH.PI;
		String status = "";
		int grade = 8;
		// TODO Auto-generated method stub

		long numero = 123098;
		double pi Math.PI;

		System.out.printf("%d In", numero);
		System.out.printf("%d %n", numero);
		System.out.printf("%d %n", numero);
		Locale.setDefault(Locale.US); //use the US format to print out numbers
		DecimalFormat formatol = new DecimalFormat("a,#.#");
		String valorFormateadol formatol.format(numero);
		System.out.printf("%s \n", valorFormateadol);
		
		System.out.println("Manejo de operador condicional");
		status = (grade >= 7) ? "Passed" : "Fail";
		System.out.println(status);
	}

}
